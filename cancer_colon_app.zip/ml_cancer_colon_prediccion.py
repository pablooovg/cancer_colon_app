# ml_cancer_colon_prediccion.py

import pandas as pd
import numpy as np
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
import shap

# Cargar datos
df = pd.read_excel("colon.xlsx")

# Columnas
cols_validas = [
    "grupo", "sexo", "edad", "imc", "calorias", "tumor",
    "extension", "alcohol", "alc.dur", "tabaco", "tab.dur", "familiares"
]
df = df[cols_validas].dropna()

# Codificación
label_encoders = {}
for col in ["grupo", "sexo", "extension", "alcohol", "tabaco", "familiares"]:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col])
    label_encoders[col] = le

# Features y target
X = df.drop("tumor", axis=1)
y = df["tumor"]

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Modelo
model = RandomForestClassifier(n_estimators=200, random_state=42)
model.fit(X_train, y_train)

# Guardar modelo y objetos
joblib.dump(model, "model_rf.pkl")
joblib.dump(label_encoders, "label_encoders.pkl")
joblib.dump(X.columns.tolist(), "feature_order.pkl")

# SHAP explainer
explainer = shap.Explainer(model, X_train)
joblib.dump(explainer, "explainer.pkl")
print("Modelo y objetos guardados correctamente.")