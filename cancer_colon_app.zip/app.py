# app.py

import streamlit as st
import pandas as pd
import joblib
import shap
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.graph_objects as go
import numpy as np

# Config
st.set_page_config(page_title="Predicción de tumor colorrectal", layout="wide")
st.title("🧬 Predicción de riesgo de tumor colorrectal")
st.markdown("Predice la probabilidad de tener un tumor colorrectal según tus datos clínicos.")

# Cargar modelo y objetos
model = joblib.load("model_rf.pkl")
label_encoders = joblib.load("label_encoders.pkl")
feature_order = joblib.load("feature_order.pkl")
explainer = joblib.load("explainer.pkl")

# Función para codificar inputs
def encode_input(value, col):
    le = label_encoders[col]
    if value not in le.classes_:
        st.error(f"Valor '{value}' no válido para '{col}'")
        st.stop()
    return le.transform([value])[0]

# Formulario
with st.form(key="formulario_prediccion"):
    col1, col2, col3 = st.columns(3)
    with col1:
        grupo = st.selectbox("Grupo", label_encoders['grupo'].classes_)
        sexo = st.selectbox("Sexo", label_encoders['sexo'].classes_)
        edad = st.slider("Edad", 0, 100, 50)
        imc = st.number_input("IMC", 10.0, 50.0, 25.0)
    with col2:
        calorias = st.number_input("Calorías diarias", 500, 8000, 2000)
        extension = st.selectbox("Extensión del tumor", label_encoders['extension'].classes_)
        alcohol = st.selectbox("Consumo de alcohol", label_encoders['alcohol'].classes_)
        alc_dur = st.slider("Duración alcohol (años)", 0, 100, 0)
    with col3:
        tabaco = st.selectbox("Consumo de tabaco", label_encoders['tabaco'].classes_)
        tab_dur = st.slider("Duración tabaco (años)", 0, 100, 0)
        familiares = st.selectbox("Antecedentes familiares", label_encoders['familiares'].classes_)

    submitted = st.form_submit_button("🔍 Predecir")

if submitted:
    try:
        input_dict = {
            "grupo": encode_input(grupo, "grupo"),
            "sexo": encode_input(sexo, "sexo"),
            "edad": edad,
            "imc": imc,
            "calorias": calorias,
            "tumor": 0,  # dummy para mantener estructura
            "extension": encode_input(extension, "extension"),
            "alcohol": encode_input(alcohol, "alcohol"),
            "alc.dur": alc_dur,
            "tabaco": encode_input(tabaco, "tabaco"),
            "tab.dur": tab_dur,
            "familiares": encode_input(familiares, "familiares")
        }

        input_df = pd.DataFrame([input_dict])[feature_order]

        # Predicción
        pred = model.predict(input_df)[0]
        prob = model.predict_proba(input_df)[0][1]  # prob de clase positiva

        st.markdown("---")
        st.subheader("🎯 Resultado de la predicción")

        resultado = "🟥 Tumor presente" if pred == 1 else "🟩 Control"
        st.write(f"### {resultado}")
        st.write(f"**Probabilidad estimada:** {prob:.2%}")

        # Visualización SHAP
        st.subheader("🔍 Interpretación con SHAP")
        try:
            shap_values = explainer(input_df)
            shap_value = shap_values[0]
            fig, ax = plt.subplots(figsize=(10, 4))
            shap.plots.waterfall(shap_value, max_display=10, show=False)
            st.pyplot(fig)
        except Exception as e:
            st.error(f"❌ Error al generar gráfico SHAP: {e}")

        # Radar Chart
        st.subheader("📊 Perfil del paciente (Radar)")
        radar_df = input_df.copy()
        radar_df_scaled = (radar_df - radar_df.min()) / (radar_df.max() - radar_df.min())
        fig_radar = go.Figure()
        fig_radar.add_trace(go.Scatterpolar(
            r=radar_df_scaled.values.flatten(),
            theta=radar_df.columns,
            fill='toself',
            name='Perfil'
        ))
        fig_radar.update_layout(polar=dict(radialaxis=dict(visible=True)), showlegend=False)
        st.plotly_chart(fig_radar, use_container_width=True)

        # Comparativas con datos reales
        df = pd.read_excel("colon.xlsx")
        df = df.dropna()

        st.subheader("📈 Comparativa de edad en la población")
        fig_hist = px.histogram(df, x="edad", color="tumor", barmode="overlay",
                                nbins=30, labels={"tumor": "Diagnóstico"})
        st.plotly_chart(fig_hist, use_container_width=True)

        st.subheader("🍷 Distribución del consumo de alcohol")
        fig_pie = px.pie(df, names="alcohol", title="Distribución alcohol")
        st.plotly_chart(fig_pie, use_container_width=True)

    except Exception as e:
        st.error(f"❌ Ocurrió un error durante la predicción: {e}")

st.markdown("---")
st.caption("Aplicación creada con ❤️ usando Streamlit, SHAP y Plotly.")





